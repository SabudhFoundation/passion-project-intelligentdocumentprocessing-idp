document.getElementById('summarizeForm').addEventListener('submit', function() {
    document.getElementById('loading').style.display = 'block';
});
