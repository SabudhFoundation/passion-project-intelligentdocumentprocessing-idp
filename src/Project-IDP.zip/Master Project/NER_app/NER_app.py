from flask import Flask, render_template, request
from transformers import AutoTokenizer, AutoModelForTokenClassification, pipeline

app = Flask(__name__)

# Load tokenizer and model for NER
tokenizer = AutoTokenizer.from_pretrained("dslim/bert-base-NER")
model = AutoModelForTokenClassification.from_pretrained("dslim/bert-base-NER")
nlp = pipeline("ner", model=model, tokenizer=tokenizer)

@app.route('/', methods=['GET', 'POST'])
def index():
    if request.method == 'POST':
        text = request.form['text']
        ner_results = nlp(text)
        entities = [(entity['word'], entity['entity']) for entity in ner_results]
        return render_template('index.html', text=text, entities=entities)
    return render_template('index.html')

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=8081)
